# Optimisation notes

See `FAIR_COMPARISON_REPORT.md` for the latest 30-candidate, validation-only search and its results. The current code gives both One-Class SVM and Isolation Forest exactly 30 configurations, uses scam-only fitting, selects thresholds by validation G-mean, and selects model settings by validation MCC. The earlier seed-2027 final-test results are development history only; a new independent test set is required for final dissertation claims.
