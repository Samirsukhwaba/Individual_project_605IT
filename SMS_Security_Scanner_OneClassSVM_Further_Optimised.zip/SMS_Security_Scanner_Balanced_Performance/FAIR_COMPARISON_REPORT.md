# Expanded fair search — validation-only report

## Purpose

The supplied final-test confusion matrix shows that One-Class SVM still makes many false-positive and false-negative errors. This update expands the search space for both algorithms equally. The goal is to find better settings using validation data without changing the scam-only training rule.

## Experimental rules

- 70% scam-only training partition.
- 15% mixed scam + verified genuine validation partition.
- 15% mixed scam + verified genuine test partition.
- Word-level and character-level TF-IDF, fitted on scam training messages only.
- TruncatedSVD: 240 components.
- Exactly 30 candidate configurations for each algorithm.
- Every candidate is fitted on scam training messages only.
- Each candidate's threshold is selected on validation data by maximising G-mean.
- Each algorithm's best configuration is selected using validation MCC, then balanced accuracy, F1 and lower error rates.
- The expanded search below uses validation data only. No final-test predictions were generated for this report.

## Search spaces

### One-Class SVM — 30 candidates

- `nu`: 0.05, 0.1, 0.3, 0.5, 0.7
- `gamma`: 0.0001, 0.001, 0.005, 0.01, 0.05, `scale`

Selected validation configuration:
- `nu = 0.7`
- `gamma = scale`

### Isolation Forest — 30 candidates

- `n_estimators`: 300, 400, 600, 800, 1000
- `max_samples`: 0.5, 0.75, 1.0
- `max_features`: 0.5, 1.0

Selected validation configuration:
- `n_estimators = 1000`
- `max_samples = 1.0`
- `max_features = 0.5`

## Validation results

| Model/configuration | TP | TN | FP | FN | G-mean | MCC |
|---|---:|---:|---:|---:|---:|---:|
| One-Class SVM — previous 9-candidate selection (`nu=0.05`, `gamma=scale`) | 550 | 1,046 | 407 | 305 | 0.681 | 0.356 |
| One-Class SVM — expanded 30-candidate selection (`nu=0.7`, `gamma=scale`) | 576 | 1,220 | 233 | 279 | 0.752 | 0.520 |
| Isolation Forest — previous 9-candidate selection (`600`, `1.0`, `0.5`) | 664 | 1,277 | 176 | 191 | 0.826 | 0.658 |
| Isolation Forest — expanded 30-candidate selection (`1000`, `1.0`, `0.5`) | 661 | 1,301 | 152 | 194 | 0.832 | 0.676 |

### Interpretation

On this validation partition, the expanded One-Class SVM search improved all four confusion-matrix counts relative to its previous selected configuration:
- TP increased by 26.
- TN increased by 174.
- FP decreased by 174.
- FN decreased by 26.

The expanded Isolation Forest search produced a small validation improvement in MCC and specificity, with a small trade-off in scam recall:
- TP decreased by 3.
- TN increased by 24.
- FP decreased by 24.
- FN increased by 3.

These are validation-only results, not final-test results. Because this validation partition has already been used in earlier model development, the expanded search may be somewhat adapted to it. A fresh independent test set is required for a defensible final dissertation evaluation.

## Why the One-Class SVM errors cannot simply be tuned away

The two error types compete when only a single threshold is moved:
- Lower threshold: more scam alerts, usually fewer missed scams, but more false alarms.
- Higher threshold: fewer false alarms, but potentially more missed scams.

Reducing both errors requires better separation in the learned feature space, not just moving the threshold. A scam-only model also has no direct examples of genuine-message patterns during training, so some overlap is expected.

## Final-test integrity

The previously displayed seed-2027 test confusion matrix has already been inspected. It is not reused to choose the new settings, and no new final-test result is claimed here. Before reporting final dissertation results, obtain new independent scam and verified genuine messages and keep them untouched until the code and parameters are frozen.
