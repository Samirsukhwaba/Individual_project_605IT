"""SMS scam novelty detection with validation-based balanced detection.

Research design:
- 70% of the combined eligible scam + genuine dataset is targeted for training.
- The training set contains scam SMS ONLY.
- Validation (about 15%) and final testing (about 15%) each contain scam + genuine SMS.
- Message templates are grouped before splitting to reduce template leakage.
- TF-IDF, SVD, normalisation and both models are fitted on scam-training SMS only.
- Thresholds and the default model are selected using mixed validation data only.
- Final-test data is used once for final reporting and is never used for selection.

Positive class (1): scam SMS.
Negative class (0): genuine SMS.
"""
from __future__ import annotations

import argparse
import json
import re
import time
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import TruncatedSVD
from sklearn.ensemble import IsolationForest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import FeatureUnion
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_curve,
)
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import Normalizer
from sklearn.svm import OneClassSVM


ROOT = Path(__file__).resolve().parent
DEFAULT_SCAM_CSV = ROOT / "data" / "scams.csv"
DEFAULT_GENUINE_CSV = ROOT / "data" / "genuine_sms.csv"
DEFAULT_RESULTS = ROOT / "results"

SCAM_CATEGORIES = {
    "banking", "others", "government", "delivery", "telecom",
    "wrong number", "hey mum/dad",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train on scam-only SMS; balance scam and genuine detection using validation SMS."
    )
    parser.add_argument("--scams", type=Path, default=DEFAULT_SCAM_CSV)
    parser.add_argument("--genuine", type=Path, default=DEFAULT_GENUINE_CSV)
    parser.add_argument("--out", type=Path, default=DEFAULT_RESULTS)
    parser.add_argument("--train", type=float, default=0.70)
    parser.add_argument("--validation", type=float, default=0.15)
    parser.add_argument("--test", type=float, default=0.15)
    parser.add_argument("--max-features", type=int, default=5000)
    parser.add_argument("--svd-components", type=int, default=240)
    parser.add_argument("--seed", type=int, default=2027)
    parser.add_argument(
        "--genuine-source", choices=("verified",), default="verified",
        help="The supplied genuine_sms.csv is treated as verified genuine data.",
    )
    args = parser.parse_args()

    fractions = (args.train, args.validation, args.test)
    if any(value <= 0 or value >= 1 for value in fractions):
        parser.error("Training, validation and testing fractions must be between 0 and 1.")
    if not np.isclose(sum(fractions), 1.0):
        parser.error("Training + validation + testing fractions must add up to 1.00.")
    if args.max_features < 10 or args.svd_components < 2:
        parser.error("--max-features must be >= 10 and --svd-components must be >= 2.")
    return args


def read_csv(path: Path) -> pd.DataFrame:
    if not Path(path).is_file():
        raise FileNotFoundError(f"CSV not found: {Path(path).resolve()}")
    return pd.read_csv(
        path, escapechar="\\", dtype=str, encoding="utf-8-sig", low_memory=False
    )


def clean_text(value: object) -> str:
    if pd.isna(value):
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def prepare_scam_data(path: Path) -> pd.DataFrame:
    data = read_csv(path)
    if "text" not in data.columns or "scam_type" not in data.columns:
        raise ValueError("Scam CSV must contain 'text' and 'scam_type' columns.")

    data["text"] = data["text"].map(clean_text)
    data["scam_type"] = data["scam_type"].fillna("").str.strip().str.casefold()

    if "language" in data.columns:
        language = data["language"].fillna("").str.strip().str.casefold()
        data = data[language.isin({"english", "en"})].copy()

    data = data[data["scam_type"].isin(SCAM_CATEGORIES)]
    data = data[data["text"].ne("")].copy()
    data["_exact_key"] = data["text"].str.casefold()
    data = data.drop_duplicates("_exact_key").reset_index(drop=True)

    if len(data) < 50:
        raise ValueError(
            f"Only {len(data)} eligible unique scam messages remain; at least 50 are required."
        )
    return data[["text", "scam_type"]].copy()


def prepare_genuine_data(path: Path, scam_data: pd.DataFrame) -> pd.DataFrame:
    data = read_csv(path)
    if "text" not in data.columns:
        raise ValueError("Genuine SMS CSV must contain a 'text' column.")

    data = data[["text"]].copy()
    data["text"] = data["text"].map(clean_text)
    data = data[data["text"].ne("")].copy()
    data["_exact_key"] = data["text"].str.casefold()
    data = data.drop_duplicates("_exact_key").reset_index(drop=True)

    if len(data) < 4:
        raise ValueError("At least four unique genuine messages are required.")

    scam_keys = set(scam_data["text"].str.casefold())
    overlap = set(data["_exact_key"]) & scam_keys
    if overlap:
        raise ValueError(
            f"{len(overlap)} exact message(s) occur in both CSV files. "
            "Resolve these conflicting labels before evaluation."
        )
    return data[["text"]].copy()


def template_group_key(message: str) -> str:
    """Normalise variable fields so template variants stay in the same split."""
    value = str(message).casefold()
    value = re.sub(r"https?://\S+|www\.\S+", " urltoken ", value)
    value = re.sub(r"\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b", " emailtoken ", value)
    value = re.sub(r"\+?\d[\d\s().-]{7,}\d", " phonetoken ", value)
    value = re.sub(r"\b\d+(?:[.,]\d+)*\b", " numbertoken ", value)
    value = re.sub(r"[^\w\s]", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def _category_distribution_error(full: pd.DataFrame, subset: pd.DataFrame, column: str) -> float:
    full_dist = full[column].value_counts(normalize=True)
    subset_dist = subset[column].value_counts(normalize=True).reindex(full_dist.index, fill_value=0)
    return float(np.abs(full_dist - subset_dist).sum())


def best_group_split(
    frame: pd.DataFrame,
    left_fraction: float,
    seed: int,
    stratify_column: str | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Group-aware split; prefer target size and, for scam data, category balance."""
    if not 0 < left_fraction < 1:
        raise ValueError("A split fraction must be between 0 and 1.")

    work = frame.copy()
    work["_group"] = work["text"].map(template_group_key)
    if work["_group"].nunique() < 2:
        raise ValueError("Not enough distinct message-template groups to create separate splits.")

    desired_rows = len(work) * left_fraction
    best_indices = None
    best_score = float("inf")

    for offset in range(120):
        splitter = GroupShuffleSplit(
            n_splits=1, train_size=left_fraction, random_state=seed + offset
        )
        left_idx, right_idx = next(splitter.split(work, groups=work["_group"]))
        left = work.iloc[left_idx]
        size_error = abs(len(left) - desired_rows) / max(len(work), 1)
        category_error = (
            _category_distribution_error(work, left, stratify_column)
            if stratify_column else 0.0
        )
        score = size_error + 0.15 * category_error
        if score < best_score:
            best_score = score
            best_indices = (left_idx, right_idx)
        if size_error == 0 and category_error == 0:
            break

    left_idx, right_idx = best_indices
    left = work.iloc[left_idx].drop(columns="_group").reset_index(drop=True)
    right = work.iloc[right_idx].drop(columns="_group").reset_index(drop=True)
    return left, right


def assert_group_separation(parts: tuple[pd.DataFrame, ...], names: tuple[str, ...]) -> None:
    group_sets = [set(part["text"].map(template_group_key)) for part in parts]
    for i in range(len(group_sets)):
        for j in range(i + 1, len(group_sets)):
            overlap = group_sets[i] & group_sets[j]
            if overlap:
                raise RuntimeError(
                    f"Template leakage detected between {names[i]} and {names[j]} "
                    f"({len(overlap)} shared template groups)."
                )


def make_splits(
    scams: pd.DataFrame, genuine: pd.DataFrame, args: argparse.Namespace
):
    """Target 70/15/15 overall while keeping the training partition scam-only."""
    total_messages = len(scams) + len(genuine)
    target_train_rows = round(args.train * total_messages)

    if target_train_rows >= len(scams):
        raise ValueError(
            "There are not enough eligible scam messages to fill 70% of the combined "
            "dataset while keeping training scam-only. Add more eligible scam messages "
            "or reduce the training percentage."
        )

    train_fraction_of_scams = target_train_rows / len(scams)
    train, remaining_scams = best_group_split(
        scams, train_fraction_of_scams, args.seed, stratify_column="scam_type"
    )

    validation_share_of_holdout = args.validation / (args.validation + args.test)
    scam_validation, scam_test = best_group_split(
        remaining_scams, validation_share_of_holdout, args.seed + 100,
        stratify_column="scam_type",
    )
    genuine_validation, genuine_test = best_group_split(
        genuine, validation_share_of_holdout, args.seed + 200
    )

    assert_group_separation(
        (train, scam_validation, scam_test),
        ("scam training", "scam validation", "scam testing"),
    )
    assert_group_separation(
        (genuine_validation, genuine_test),
        ("genuine validation", "genuine testing"),
    )
    return train, scam_validation, scam_test, genuine_validation, genuine_test


def fit_text_pipeline(
    train_texts: pd.Series,
    scam_validation_texts: pd.Series,
    scam_test_texts: pd.Series,
    genuine_validation_texts: pd.Series,
    genuine_test_texts: pd.Series,
    args: argparse.Namespace,
) -> dict:
    """Fit all text transformations on scam training texts ONLY."""
    # Both vectorizers are fitted on scam training messages ONLY.
    # Word n-grams capture terms and short phrases; character n-grams capture
    # spelling variations, obfuscation and related word forms.
    tfidf = FeatureUnion([
        ("word", TfidfVectorizer(
            lowercase=True,
            strip_accents="unicode",
            ngram_range=(1, 2),
            max_features=args.max_features,
            min_df=3,
            max_df=0.95,
            sublinear_tf=True,
            token_pattern=r"(?u)\b\w+\b",
        )),
        ("char", TfidfVectorizer(
            lowercase=True,
            analyzer="char_wb",
            ngram_range=(3, 5),
            max_features=args.max_features,
            min_df=3,
            sublinear_tf=True,
        )),
    ])
    x_train_sparse = tfidf.fit_transform(train_texts)

    x_scam_val_sparse = tfidf.transform(scam_validation_texts)
    x_scam_test_sparse = tfidf.transform(scam_test_texts)
    x_genuine_val_sparse = tfidf.transform(genuine_validation_texts)
    x_genuine_test_sparse = tfidf.transform(genuine_test_texts)

    components = min(
        args.svd_components,
        x_train_sparse.shape[0] - 1,
        x_train_sparse.shape[1] - 1,
    )
    if components < 2:
        raise ValueError("Not enough scam-training vocabulary for TruncatedSVD.")

    svd = TruncatedSVD(n_components=components, random_state=args.seed)
    normalizer = Normalizer()

    x_train = normalizer.fit_transform(svd.fit_transform(x_train_sparse)).astype(np.float32)
    x_scam_val = normalizer.transform(svd.transform(x_scam_val_sparse)).astype(np.float32)
    x_scam_test = normalizer.transform(svd.transform(x_scam_test_sparse)).astype(np.float32)
    x_genuine_val = normalizer.transform(svd.transform(x_genuine_val_sparse)).astype(np.float32)
    x_genuine_test = normalizer.transform(svd.transform(x_genuine_test_sparse)).astype(np.float32)

    return {
        "x_train": x_train,
        "x_scam_val": x_scam_val,
        "x_scam_test": x_scam_test,
        "x_genuine_val": x_genuine_val,
        "x_genuine_test": x_genuine_test,
        "known_train": np.asarray(x_train_sparse.getnnz(axis=1)).ravel() > 0,
        "known_scam_val": np.asarray(x_scam_val_sparse.getnnz(axis=1)).ravel() > 0,
        "known_scam_test": np.asarray(x_scam_test_sparse.getnnz(axis=1)).ravel() > 0,
        "known_genuine_val": np.asarray(x_genuine_val_sparse.getnnz(axis=1)).ravel() > 0,
        "known_genuine_test": np.asarray(x_genuine_test_sparse.getnnz(axis=1)).ravel() > 0,
        "tfidf": tfidf,
        "svd": svd,
        "normalizer": normalizer,
    }


def predictions_from_scores(
    scores: np.ndarray, threshold: float, known_vocabulary: np.ndarray
) -> np.ndarray:
    """1 = scam-like; 0 = outside learned scam pattern."""
    return ((scores >= threshold) & known_vocabulary).astype(int)


def calculate_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Return class counts and rates; class 1 is scam and class 0 is genuine."""
    matrix = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = (int(value) for value in matrix.ravel())
    fpr = fp / (fp + tn) if (fp + tn) else float("nan")
    fnr = fn / (fn + tp) if (fn + tp) else float("nan")
    specificity = tn / (tn + fp) if (tn + fp) else float("nan")
    sensitivity = tp / (tp + fn) if (tp + fn) else float("nan")
    return {
        "confusion_matrix": matrix,
        "TP": tp,
        "TN": tn,
        "FP": fp,
        "FN": fn,
        "Accuracy": float(accuracy_score(y_true, y_pred)),
        "Balanced accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "Precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "Recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "Specificity": float(specificity),
        "G-mean": float(np.sqrt(max(sensitivity, 0.0) * max(specificity, 0.0))),
        "F1-score": float(f1_score(y_true, y_pred, zero_division=0)),
        "False positive rate": float(fpr),
        "False negative rate": float(fnr),
        "MCC": float(matthews_corrcoef(y_true, y_pred)),
    }


def choose_validation_threshold(
    scam_scores: np.ndarray,
    known_scam: np.ndarray,
    genuine_scores: np.ndarray,
    known_genuine: np.ndarray,
) -> tuple[float, dict]:
    """Choose a threshold that keeps both scam recall and genuine specificity high.

    The threshold is selected on mixed validation data by maximising the geometric
    mean (G-mean) of scam recall and genuine specificity. This penalises a threshold
    that performs very poorly on either class. Ties use MCC, balanced accuracy and
    then lower FPR/FNR. Unknown-vocabulary messages remain outside the learned scam
    group and count as not-detected scams when they are actual scam messages.
    """
    y_true = np.concatenate([
        np.ones(len(scam_scores), dtype=int),
        np.zeros(len(genuine_scores), dtype=int),
    ])
    # A very low sentinel ensures unknown-vocabulary messages are always
    # treated as predicted non-scam in the ROC threshold search.
    lowest = -1e300
    combined_scores = np.concatenate([
        np.where(known_scam, scam_scores, lowest),
        np.where(known_genuine, genuine_scores, lowest),
    ])

    fpr, tpr, thresholds = roc_curve(
        y_true, combined_scores, pos_label=1, drop_intermediate=False
    )
    valid = np.isfinite(thresholds) & (thresholds > -1e299)
    fpr, tpr, thresholds = fpr[valid], tpr[valid], thresholds[valid]

    # Include an all-negative decision as a candidate.
    thresholds = np.append(
        thresholds, np.nextafter(float(np.max(combined_scores[combined_scores > lowest])), np.inf)
    )
    fpr = np.append(fpr, 0.0)
    tpr = np.append(tpr, 0.0)

    specificity = 1.0 - fpr
    balanced = (tpr + specificity) / 2.0
    geometric_mean = np.sqrt(tpr * specificity)

    positives = float(np.sum(y_true == 1))
    negatives = float(np.sum(y_true == 0))
    tp = tpr * positives
    fp = fpr * negatives
    fn = positives - tp
    tn = negatives - fp

    denominator = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = np.divide(
        tp * tn - fp * fn, denominator,
        out=np.zeros_like(denominator), where=denominator > 0
    )
    precision = np.divide(
        tp, tp + fp, out=np.zeros_like(tp), where=(tp + fp) > 0
    )
    f1 = np.divide(
        2 * precision * tpr, precision + tpr,
        out=np.zeros_like(tp), where=(precision + tpr) > 0
    )
    fnr = 1.0 - tpr

    best_index = max(
        range(len(thresholds)),
        key=lambda i: (
            geometric_mean[i], mcc[i], balanced[i], f1[i], -fpr[i], -fnr[i]
        ),
    )
    threshold = float(thresholds[best_index])

    y_pred = np.concatenate([
        predictions_from_scores(scam_scores, threshold, known_scam),
        predictions_from_scores(genuine_scores, threshold, known_genuine),
    ])
    metrics = calculate_metrics(y_true, y_pred)
    metrics["G-mean"] = float(geometric_mean[best_index])
    metrics["Threshold selection rule"] = (
        "Maximum validation G-mean (geometric mean of scam recall and genuine specificity); "
        "ties use higher MCC and balanced accuracy, then lower FPR and FNR."
    )
    return threshold, metrics


def save_final_confusion_matrix(
    matrix: np.ndarray, model_name: str, output_dir: Path
) -> None:
    """Save exactly one final-test confusion matrix per model."""
    slug = model_name.lower().replace(" ", "_").replace("-", "_")
    fig, ax = plt.subplots(figsize=(6, 5))
    display = ConfusionMatrixDisplay(
        confusion_matrix=matrix,
        display_labels=["Genuine (0)", "Scam (1)"],
    )
    display.plot(ax=ax, values_format="d", colorbar=False, cmap="Blues")
    ax.set_title(f"Final-test confusion matrix — {model_name}")
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("Actual label")
    fig.tight_layout()
    fig.savefig(output_dir / f"confusion_matrix_{slug}.png", dpi=180)
    plt.close(fig)


def write_split_counts(
    train: pd.DataFrame,
    scam_validation: pd.DataFrame,
    scam_test: pd.DataFrame,
    genuine_validation: pd.DataFrame,
    genuine_test: pd.DataFrame,
    total_messages: int,
    output_dir: Path,
) -> None:
    rows = [
        {
            "Split": "Training",
            "Scam messages": len(train),
            "Genuine messages": 0,
            "Total messages": len(train),
        },
        {
            "Split": "Validation",
            "Scam messages": len(scam_validation),
            "Genuine messages": len(genuine_validation),
            "Total messages": len(scam_validation) + len(genuine_validation),
        },
        {
            "Split": "Testing",
            "Scam messages": len(scam_test),
            "Genuine messages": len(genuine_test),
            "Total messages": len(scam_test) + len(genuine_test),
        },
    ]
    for row in rows:
        row["Percentage of combined dataset"] = round(
            100 * row["Total messages"] / total_messages, 2
        )
    pd.DataFrame(rows).to_csv(output_dir / "split_counts.csv", index=False)


def clear_old_outputs(output_dir: Path) -> None:
    """Remove stale results so old matrices/metrics cannot be mistaken for this run."""
    patterns = [
        "confusion_matrix_*.png",
        "*.csv",
        "*.json",
        "model_*.joblib",
        "selected_model.joblib",
    ]
    for pattern in patterns:
        for path in output_dir.glob(pattern):
            if path.is_file():
                path.unlink()


def main() -> None:
    args = parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    clear_old_outputs(args.out)

    print("\nSMS SECURITY SCANNER — BALANCED PERFORMANCE EVALUATION")
    print("Training: scam messages ONLY.")
    print("Validation/testing: mixed scam + verified genuine messages.")
    print("Threshold objective: maximise G-mean to keep both class detection rates strong.")
    print("Model selection: highest validation MCC, then balanced accuracy.")
    print("Fair comparison: 30 candidate configurations per algorithm.")
    print("Both algorithms use the same scam-only training data, validation split,")
    print("G-mean threshold selection and MCC-based model-selection rule.")
    print(f"Text representation: {args.svd_components} SVD components.")

    scams = prepare_scam_data(args.scams)
    genuine = prepare_genuine_data(args.genuine, scams)
    total_messages = len(scams) + len(genuine)

    train, scam_val, scam_test, genuine_val, genuine_test = make_splits(
        scams, genuine, args
    )
    write_split_counts(
        train, scam_val, scam_test, genuine_val, genuine_test,
        total_messages, args.out,
    )

    validation_total = len(scam_val) + len(genuine_val)
    testing_total = len(scam_test) + len(genuine_test)
    print("\nDATA SPLIT COUNTS")
    print(f"  Training:   {len(train):,} scam only ({len(train) / total_messages:.1%} combined)")
    print(
        f"  Validation: {len(scam_val):,} scam + {len(genuine_val):,} genuine "
        f"({validation_total / total_messages:.1%} combined)"
    )
    print(
        f"  Testing:    {len(scam_test):,} scam + {len(genuine_test):,} genuine "
        f"({testing_total / total_messages:.1%} combined)"
    )

    print("\nFitting word + character TF-IDF/SVD using scam training messages only...")
    features = fit_text_pipeline(
        train["text"], scam_val["text"], scam_test["text"],
        genuine_val["text"], genuine_test["text"], args,
    )
    print(f"Combined TF-IDF features: {len(features['tfidf'].get_feature_names_out()):,}")

    # Small, pre-defined parameter grids. Every candidate is fitted on scam
    # training data only. Mixed validation data is used for threshold and
    # hyperparameter selection. Final test data is not consulted.
    candidate_settings = {
        # Equal tuning budget: 5 nu values x 6 gamma values = 30 candidates.
        # The wider nu range is included because the earlier best candidate
        # was at the upper edge of the old search range.
        "One-Class SVM": [
            {"nu": nu, "gamma": gamma}
            for nu in (0.05, 0.1, 0.3, 0.5, 0.7)
            for gamma in (0.0001, 0.001, 0.005, 0.01, 0.05, "scale")
        ],
        # Equal tuning budget: 5 tree counts x 3 sample fractions x 2 feature
        # fractions = 30 candidates.
        "Isolation Forest": [
            {
                "n_estimators": n_estimators,
                "max_samples": max_samples,
                "max_features": max_features,
            }
            for n_estimators in (300, 400, 600, 800, 1000)
            for max_samples in (0.5, 0.75, 1.0)
            for max_features in (0.5, 1.0)
        ],
    }

    def create_model(model_name: str, settings: dict):
        if model_name == "One-Class SVM":
            return OneClassSVM(
                kernel="rbf",
                gamma=settings["gamma"],
                nu=settings["nu"],
                cache_size=1000,
            )
        return IsolationForest(
            n_estimators=settings["n_estimators"],
            max_samples=settings["max_samples"],
            max_features=settings["max_features"],
            contamination="auto",
            bootstrap=False,
            random_state=args.seed,
            n_jobs=-1,
        )

    validation_records = []
    final_records = []
    selected_models = {}

    for model_name, settings_list in candidate_settings.items():
        print(f"\nTuning {model_name} using scam-only fitting and validation scoring...")
        candidate_results = []

        for settings in settings_list:
            model = create_model(model_name, settings)
            started = time.perf_counter()
            model.fit(features["x_train"])
            training_seconds = time.perf_counter() - started

            scam_val_scores = model.decision_function(features["x_scam_val"]).ravel()
            genuine_val_scores = model.decision_function(features["x_genuine_val"]).ravel()
            threshold, validation_metrics = choose_validation_threshold(
                scam_val_scores,
                features["known_scam_val"],
                genuine_val_scores,
                features["known_genuine_val"],
            )

            candidate_results.append({
                "model": model,
                "settings": settings,
                "threshold": threshold,
                "metrics": validation_metrics,
                "training_seconds": training_seconds,
            })

        # MCC uses TP, TN, FP and FN together. Balanced accuracy is the first
        # tie-breaker and gives equal importance to both message classes.
        best_candidate = max(
            candidate_results,
            key=lambda item: (
                item["metrics"]["MCC"],
                item["metrics"]["Balanced accuracy"],
                item["metrics"]["F1-score"],
                -item["metrics"]["False positive rate"],
                -item["metrics"]["False negative rate"],
            ),
        )
        selected_models[model_name] = best_candidate

        model = best_candidate["model"]
        settings = best_candidate["settings"]
        threshold = best_candidate["threshold"]
        validation_metrics = best_candidate["metrics"]
        training_seconds = best_candidate["training_seconds"]

        # Training acceptance is diagnostic only; it is not used for selection.
        train_scores = model.decision_function(features["x_train"]).ravel()
        train_predictions = predictions_from_scores(
            train_scores, threshold, features["known_train"]
        )
        training_scam_acceptance = float(np.mean(train_predictions == 1))
        train_val_gap = training_scam_acceptance - validation_metrics["Recall"]

        validation_records.append({
            "Model": model_name,
            "Selected settings": json.dumps(settings, sort_keys=True),
            "Validation TP": validation_metrics["TP"],
            "Validation TN": validation_metrics["TN"],
            "Validation FP": validation_metrics["FP"],
            "Validation FN": validation_metrics["FN"],
            "Accuracy": validation_metrics["Accuracy"],
            "Balanced accuracy": validation_metrics["Balanced accuracy"],
            "Precision": validation_metrics["Precision"],
            "Recall": validation_metrics["Recall"],
            "Specificity": validation_metrics["Specificity"],
            "G-mean": validation_metrics["G-mean"],
            "F1-score": validation_metrics["F1-score"],
            "False positive rate": validation_metrics["False positive rate"],
            "False negative rate": validation_metrics["False negative rate"],
            "MCC": validation_metrics["MCC"],
            "Threshold selection rule": validation_metrics["Threshold selection rule"],
            "Decision threshold": threshold,
            "Training scam acceptance": training_scam_acceptance,
            "Train-validation scam recall gap": train_val_gap,
            "Training seconds": training_seconds,
        })

        # Freeze model and threshold before touching the final-test partition.
        scam_test_scores = model.decision_function(features["x_scam_test"]).ravel()
        genuine_test_scores = model.decision_function(features["x_genuine_test"]).ravel()
        scam_test_predictions = predictions_from_scores(
            scam_test_scores, threshold, features["known_scam_test"]
        )
        genuine_test_predictions = predictions_from_scores(
            genuine_test_scores, threshold, features["known_genuine_test"]
        )

        y_test_true = np.concatenate([
            np.ones(len(scam_test), dtype=int),
            np.zeros(len(genuine_test), dtype=int),
        ])
        y_test_pred = np.concatenate([
            scam_test_predictions,
            genuine_test_predictions,
        ])
        final_metrics = calculate_metrics(y_test_true, y_test_pred)
        final_matrix = final_metrics.pop("confusion_matrix")

        final_records.append({
            "Model": model_name,
            "Selected settings": json.dumps(settings, sort_keys=True),
            "Testing scam messages": len(scam_test),
            "Testing genuine messages": len(genuine_test),
            "Genuine source": "verified",
            "True positives": final_metrics["TP"],
            "True negatives": final_metrics["TN"],
            "False positives": final_metrics["FP"],
            "False negatives": final_metrics["FN"],
            "Accuracy": final_metrics["Accuracy"],
            "Balanced accuracy": final_metrics["Balanced accuracy"],
            "Precision": final_metrics["Precision"],
            "Recall": final_metrics["Recall"],
            "Specificity": final_metrics["Specificity"],
            "G-mean": final_metrics["G-mean"],
            "F1-score": final_metrics["F1-score"],
            "False positive rate": final_metrics["False positive rate"],
            "False negative rate": final_metrics["False negative rate"],
            "MCC": final_metrics["MCC"],
            "Decision threshold from validation": threshold,
        })

        save_final_confusion_matrix(final_matrix, model_name, args.out)

        slug = model_name.lower().replace(" ", "_").replace("-", "_")
        bundle = {
            "model": model,
            "tfidf": features["tfidf"],
            "svd": features["svd"],
            "normalizer": features["normalizer"],
            "decision_threshold": threshold,
            "model_name": model_name,
            "model_settings": settings,
            "training_data": "scam messages only",
            "genuine_used_in_training": False,
            "threshold_objective": (
                "Maximum validation G-mean (scam recall balanced with genuine specificity); "
                "ties use higher MCC and balanced accuracy."
            ),
            "positive_label": "scam-like / inside learned scam pattern",
            "negative_label": "outside learned scam pattern / not confirmed genuine",
            "unknown_vocabulary_policy": "manual review warning; not confirmed genuine",
        }
        joblib.dump(bundle, args.out / f"model_{slug}.joblib")

        print(
            f"  Selected settings: {settings}; validation MCC={validation_metrics['MCC']:.3f}, "
            f"balanced accuracy={validation_metrics['Balanced accuracy']:.3f}, "
            f"recall={validation_metrics['Recall']:.3f}, "
            f"specificity={validation_metrics['Specificity']:.3f}"
        )
        print(
            f"  Final test: TP={final_metrics['TP']}, TN={final_metrics['TN']}, "
            f"FP={final_metrics['FP']}, FN={final_metrics['FN']}"
        )

    validation_df = pd.DataFrame(validation_records)
    final_df = pd.DataFrame(final_records)
    validation_df.to_csv(args.out / "validation_metrics.csv", index=False)
    final_df.to_csv(args.out / "final_test_metrics.csv", index=False)

    # Select the application model using validation MCC only (test remains untouched).
    ranked = validation_df.sort_values(
        ["MCC", "Balanced accuracy", "F1-score", "False positive rate", "False negative rate"],
        ascending=[False, False, False, True, True],
        kind="mergesort",
    )
    winner = ranked.iloc[0]
    chosen_model = str(winner["Model"])

    metadata = {
        "chosen_model": chosen_model,
        "selection_rule": (
            "Highest validation MCC, which considers TP, TN, FP and FN together; "
            "ties use higher balanced accuracy and F1, then lower FPR and FNR."
        ),
        "threshold_objective": (
            "Maximum validation G-mean, balancing scam recall and genuine-message specificity."
        ),
        "selected_using_final_test": False,
        "training_uses_scam_only": True,
        "genuine_used_in_training": False,
        "validation_contains_scam_and_genuine": True,
        "testing_contains_scam_and_genuine": True,
        "genuine_source": "verified",
        "selected_validation_balanced_accuracy": float(winner["Balanced accuracy"]),
        "selected_validation_recall": float(winner["Recall"]),
        "selected_validation_specificity": float(winner["Specificity"]),
        "selected_validation_fpr": float(winner["False positive rate"]),
        "selected_validation_fnr": float(winner["False negative rate"]),
        "selected_validation_mcc": float(winner["MCC"]),
        "selected_validation_f1": float(winner["F1-score"]),
        "selected_model_settings": str(winner["Selected settings"]),
        "feature_extraction": "word-level and character-level TF-IDF, followed by TruncatedSVD and L2 normalisation",
        "svd_components": int(args.svd_components),
        "hyperparameter_selection": (
            "Exactly 30 candidate configurations per algorithm; both use the same mixed "
            "validation data, G-mean threshold selection and MCC-based model selection. "
            "Every candidate is fitted using scam training messages only."
        ),
        "training_template_grouped": True,
        "tfidf_svd_normalizer_fit_on_scam_training_only": True,
        "overfitting_checks": [
            "Exact duplicates removed before splitting.",
            "Variable-field message templates grouped before splitting.",
            "No normalised scam template group crosses scam train/validation/test.",
            "No normalised genuine template group crosses genuine validation/test.",
            "Word and character TF-IDF, SVD and Normalizer are fitted on scam training messages only.",
            "Hyperparameters and thresholds are selected using validation data only.",
            "Final test is not used for threshold or model selection.",
        ],
        "warning": (
            "One-class training cannot guarantee that every genuine message is outside "
            "the learned scam pattern or that every unseen scam is inside it. "
            "Outside the learned scam pattern does not prove a message is safe."
        ),
    }
    (args.out / "model_selection.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )

    print("\nVALIDATION RESULTS — USED FOR MODEL AND THRESHOLD SELECTION")
    print(validation_df[
        ["Model", "Validation TP", "Validation TN", "Validation FP", "Validation FN",
         "G-mean", "Balanced accuracy", "Precision", "Recall", "Specificity", "MCC"]
    ].to_string(index=False, float_format=lambda value: f"{value:.3f}"))

    print(f"\nDefault application model selected using validation: {chosen_model}")

    print("\nFINAL TEST RESULTS — NOT USED FOR MODEL SELECTION")
    print(final_df[
        ["Model", "True positives", "True negatives", "False positives", "False negatives",
         "Accuracy", "Precision", "Recall", "Specificity", "G-mean", "F1-score", "MCC"]
    ].to_string(index=False, float_format=lambda value: f"{value:.3f}"))

    print("\nSaved outputs: two selected models, validation/final metrics, split counts,")
    print("model-selection record and exactly TWO final-test confusion matrices.")
    print(f"Results folder: {args.out.resolve()}")


if __name__ == "__main__":
    main()
