"""
Native desktop GUI for the SMS Security Scanner.
Run from the project folder with: python desktop_app.py

Uses Tkinter (no Streamlit server and no localhost browser page).
The trained models and prediction pipeline are reused from scanner_core.py.
"""
from __future__ import annotations

import os
import platform
import subprocess
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import pandas as pd

from scanner_core import RESULTS, available_models, scan_message, selection_info

MAX_BATCH_ROWS = 10_000


class SMSScannerDesktop(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SMS Security Scanner")
        self.geometry("1000x730")
        self.minsize(820, 620)
        self.configure(bg="#F3F6FA")

        self.batch_data = None
        self.batch_results = None

        self._style()
        self._header()
        self._model_selector()
        self._tabs()
        self.refresh_models()
        self.refresh_evaluation()

    def _style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#F3F6FA")
        style.configure("TLabel", background="#F3F6FA", foreground="#203047",
                        font=("Helvetica", 10))
        style.configure("Title.TLabel", font=("Helvetica", 22, "bold"),
                        foreground="#172D46", background="#F3F6FA")
        style.configure("Section.TLabel", font=("Helvetica", 14, "bold"),
                        foreground="#203047", background="#F3F6FA")
        style.configure("TButton", padding=(11, 7), font=("Helvetica", 10))
        style.configure("TNotebook.Tab", padding=(14, 8),
                        font=("Helvetica", 10, "bold"))
        style.configure("Treeview", rowheight=26, font=("Helvetica", 9))
        style.configure("Treeview.Heading", font=("Helvetica", 9, "bold"))

    def _header(self):
        header = ttk.Frame(self, padding=(22, 18, 22, 8))
        header.pack(fill="x")
        ttk.Label(header, text="🛡  SMS Security Scanner",
                  style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Native Mac desktop app  •  One-Class SVM vs Isolation Forest  •  Scam-only training",
        ).pack(anchor="w", pady=(5, 0))

        tk.Label(
            self,
            text=("Research prototype: “Outside learned scam pattern” does NOT prove a message is genuine. "
                  "Do not automatically block or delete messages based on this result."),
            bg="#FFF2D2", fg="#674B00", padx=12, pady=9,
            justify="left", wraplength=930, font=("Helvetica", 10),
        ).pack(fill="x", padx=22, pady=(8, 10))

    def _model_selector(self):
        row = ttk.Frame(self, padding=(22, 2, 22, 12))
        row.pack(fill="x")
        ttk.Label(row, text="Detection model:").pack(side="left")
        self.model_var = tk.StringVar()
        self.model_box = ttk.Combobox(
            row, textvariable=self.model_var, state="readonly", width=23
        )
        self.model_box.pack(side="left", padx=9)
        ttk.Button(row, text="Refresh models", command=self.refresh_models).pack(side="left")
        self.model_status = ttk.Label(row, text="")
        self.model_status.pack(side="left", padx=12)

    def _tabs(self):
        tabs = ttk.Notebook(self)
        tabs.pack(fill="both", expand=True, padx=22, pady=(0, 18))

        self.scan_tab = ttk.Frame(tabs, padding=16)
        self.batch_tab = ttk.Frame(tabs, padding=16)
        self.eval_tab = ttk.Frame(tabs, padding=16)
        tabs.add(self.scan_tab, text="Scan one SMS")
        tabs.add(self.batch_tab, text="Scan a CSV")
        tabs.add(self.eval_tab, text="Model evaluation")

        self._scan_tab_ui()
        self._batch_tab_ui()
        self._eval_tab_ui()

    def refresh_models(self):
        models = available_models()
        self.model_box["values"] = models
        if not models:
            self.model_var.set("")
            self.model_status.configure(text="No trained models. Run train_evaluate.py first.")
            return
        info = selection_info() or {}
        preferred = info.get("chosen_model")
        self.model_var.set(preferred if preferred in models else models[0])
        if preferred in models:
            fpr = info.get("selected_validation_false_positive_rate")
            if fpr is not None and float(fpr) > 0.10:
                self.model_status.configure(
                    text=f"Validation-selected: {preferred} (high false-positive rate; research use only)"
                )
            else:
                self.model_status.configure(text=f"Default selected using validation: {preferred}")
        else:
            self.model_status.configure(text="Trained model files found; no validation-selected default yet.")

    def _scan_tab_ui(self):
        ttk.Label(self.scan_tab, text="Check an SMS message",
                  style="Section.TLabel").pack(anchor="w")
        ttk.Label(
            self.scan_tab,
            text="Paste an SMS below, select a model above, and click Scan SMS.",
        ).pack(anchor="w", pady=(5, 10))

        self.sms_text = tk.Text(
            self.scan_tab, height=8, wrap="word", font=("Helvetica", 12),
            relief="solid", bd=1, padx=9, pady=9,
        )
        self.sms_text.pack(fill="x")
        self.sms_text.insert(
            "1.0", "Your bank account has been suspended. Verify your details immediately."
        )

        buttons = ttk.Frame(self.scan_tab)
        buttons.pack(fill="x", pady=10)
        ttk.Button(buttons, text="Scan SMS", command=self.scan_one).pack(side="left")
        ttk.Button(buttons, text="Clear", command=self.clear_scan).pack(side="left", padx=8)

        self.result_box = tk.Frame(
            self.scan_tab, bg="white", padx=15, pady=14,
            highlightbackground="#D8E0EA", highlightthickness=1,
        )
        self.result_box.pack(fill="both", expand=True, pady=(5, 0))
        self.result_title = tk.Label(
            self.result_box, text="Ready to scan", bg="white", fg="#203047",
            font=("Helvetica", 15, "bold"), anchor="w",
        )
        self.result_title.pack(fill="x")
        self.result_explanation = tk.Label(
            self.result_box, text="Your result and explanation will appear here.",
            bg="white", fg="#526274", font=("Helvetica", 10),
            justify="left", anchor="w", wraplength=900,
        )
        self.result_explanation.pack(fill="x", pady=(9, 12))
        self.result_details = tk.Label(
            self.result_box, text="", bg="white", fg="#526274",
            font=("Menlo", 9), anchor="w", justify="left",
        )
        self.result_details.pack(fill="x")

    def clear_scan(self):
        self.sms_text.delete("1.0", "end")
        for widget in (self.result_box, self.result_title,
                       self.result_explanation, self.result_details):
            widget.configure(bg="white")
        self.result_title.configure(text="Ready to scan", fg="#203047")
        self.result_explanation.configure(text="Your result and explanation will appear here.",
                                          fg="#526274")
        self.result_details.configure(text="")

    def scan_one(self):
        message = self.sms_text.get("1.0", "end").strip()
        if not message:
            messagebox.showwarning("Message required", "Please enter an SMS message.")
            return
        model = self.model_var.get().strip()
        if not model:
            messagebox.showerror("Models not found",
                                 "Run train_evaluate.py before scanning messages.")
            return
        try:
            result = scan_message(message, model)
        except Exception as exc:
            messagebox.showerror("Could not scan message", str(exc))
            return

        if result.get("low_evidence"):
            bg, fg = "#FFF5DF", "#765300"
            title = "INSUFFICIENT EVIDENCE — MANUAL REVIEW"
        elif result["prediction"] == 1:
            bg, fg = "#FDECEC", "#9D2525"
            title = "⚠  SCAM-LIKE — INSIDE LEARNED SCAM PATTERN"
        else:
            bg, fg = "#EAF4EE", "#24613B"
            title = "OUTSIDE LEARNED SCAM PATTERN — NOT CONFIRMED GENUINE"

        for widget in (self.result_box, self.result_title,
                       self.result_explanation, self.result_details):
            widget.configure(bg=bg)
        self.result_title.configure(text=title, fg=fg)
        self.result_explanation.configure(text=result["explanation"], fg=fg)
        score = "N/A (no known vocabulary overlap)" if result["score"] is None else result["score"]
        self.result_details.configure(
            text=(f"Model: {result['model']}    Decision score: {score}    "
                  f"Threshold: {result['threshold']}    "
                  f"Known TF-IDF terms: {result['known_tfidf_terms']}")
        )

    def _batch_tab_ui(self):
        ttk.Label(self.batch_tab, text="Scan multiple SMS messages",
                  style="Section.TLabel").pack(anchor="w")
        ttk.Label(
            self.batch_tab,
            text=f"Choose a CSV with a column named 'text' (maximum {MAX_BATCH_ROWS:,} rows).",
        ).pack(anchor="w", pady=(5, 10))

        row = ttk.Frame(self.batch_tab)
        row.pack(fill="x")
        ttk.Button(row, text="Choose CSV file", command=self.choose_csv).pack(side="left")
        self.csv_label = ttk.Label(row, text="No file selected")
        self.csv_label.pack(side="left", padx=10)

        self.progress = ttk.Progressbar(self.batch_tab, maximum=100)
        self.progress.pack(fill="x", pady=12)

        actions = ttk.Frame(self.batch_tab)
        actions.pack(fill="x", pady=(0, 9))
        ttk.Button(actions, text="Scan messages", command=self.scan_csv).pack(side="left")
        ttk.Button(actions, text="Save results CSV", command=self.save_csv_results).pack(
            side="left", padx=8
        )

        frame = ttk.Frame(self.batch_tab)
        frame.pack(fill="both", expand=True)
        cols = ("row", "group", "score", "warning")
        self.batch_tree = ttk.Treeview(frame, columns=cols, show="headings", height=13)
        for col, title, width in [
            ("row", "Row", 55), ("group", "Predicted group", 500),
            ("score", "Decision score", 140), ("warning", "Warning", 90),
        ]:
            self.batch_tree.heading(col, text=title)
            self.batch_tree.column(col, width=width, anchor="w")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.batch_tree.yview)
        self.batch_tree.configure(yscrollcommand=scroll.set)
        self.batch_tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.batch_status = ttk.Label(self.batch_tab, text="")
        self.batch_status.pack(anchor="w", pady=(8, 0))

    def choose_csv(self):
        path = filedialog.askopenfilename(
            title="Choose SMS CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            data = pd.read_csv(path)
        except Exception as exc:
            messagebox.showerror("Could not read CSV", str(exc))
            return
        if "text" not in data.columns:
            messagebox.showerror("Missing column", "CSV must contain a column named 'text'.")
            return
        if len(data) > MAX_BATCH_ROWS:
            messagebox.showerror("Too many rows", f"Maximum is {MAX_BATCH_ROWS:,} rows.")
            return
        self.batch_data = data
        self.csv_label.configure(text=Path(path).name)
        self.batch_status.configure(text=f"Loaded {len(data):,} messages.")
        self.progress["value"] = 0
        for item in self.batch_tree.get_children():
            self.batch_tree.delete(item)

    def scan_csv(self):
        if self.batch_data is None:
            messagebox.showinfo("Choose a CSV", "Choose a CSV file first.")
            return
        model = self.model_var.get().strip()
        if not model:
            messagebox.showerror("Models not found", "Run train_evaluate.py first.")
            return

        rows = self.batch_data["text"].fillna("").astype(str).tolist()
        records = []
        for item in self.batch_tree.get_children():
            self.batch_tree.delete(item)
        self.progress["value"] = 0

        try:
            for i, text in enumerate(rows, start=1):
                if text.strip():
                    result = scan_message(text, model)
                    record = {
                        "text": text, "predicted_group": result["group"],
                        "prediction": result["prediction"], "model": model,
                        "decision_score": result["score"], "threshold": result["threshold"],
                        "known_tfidf_terms": result["known_tfidf_terms"],
                        "warning": result["warning"], "explanation": result["explanation"],
                    }
                    score = "N/A" if result["score"] is None else f"{result['score']:.5f}"
                    group = result["group"]
                    warning = "YES" if result["warning"] else "No"
                else:
                    record = {
                        "text": text, "predicted_group": "EMPTY MESSAGE",
                        "prediction": None, "model": model, "decision_score": None,
                        "threshold": None, "known_tfidf_terms": 0,
                        "warning": False, "explanation": "The message is empty.",
                    }
                    score, group, warning = "N/A", "EMPTY MESSAGE", "No"

                records.append(record)
                self.batch_tree.insert("", "end", values=(i, group, score, warning))
                self.progress["value"] = i / max(len(rows), 1) * 100
                self.update_idletasks()
        except Exception as exc:
            messagebox.showerror("Batch scan failed", str(exc))
            return

        self.batch_results = pd.DataFrame(records)
        self.batch_status.configure(text=f"Scanned {len(records):,} messages using {model}.")

    def save_csv_results(self):
        if self.batch_results is None:
            messagebox.showinfo("No results", "Scan a CSV before saving results.")
            return
        path = filedialog.asksaveasfilename(
            title="Save scan results", defaultextension=".csv",
            initialfile="sms_scan_predictions.csv",
            filetypes=[("CSV files", "*.csv")],
        )
        if not path:
            return
        try:
            self.batch_results.to_csv(path, index=False, encoding="utf-8-sig")
        except Exception as exc:
            messagebox.showerror("Could not save CSV", str(exc))
            return
        messagebox.showinfo("Saved", f"Results saved to:\n{path}")

    def _eval_tab_ui(self):
        ttk.Label(self.eval_tab, text="Model evaluation and comparison",
                  style="Section.TLabel").pack(anchor="w")
        ttk.Label(
            self.eval_tab,
            text=("The application default is selected using validation results. "
                  "Final-test results are kept separate and are not used to choose the winner."),
            wraplength=900,
        ).pack(anchor="w", pady=(5, 8))

        self.selection_note = tk.Label(
            self.eval_tab, text="Model-selection information will appear here.",
            bg="#E8F1FB", fg="#203047", padx=10, pady=8,
            justify="left", anchor="w", wraplength=900, font=("Helvetica", 10, "bold"),
        )
        self.selection_note.pack(fill="x", pady=(0, 10))

        buttons = ttk.Frame(self.eval_tab)
        buttons.pack(fill="x", pady=(0, 8))
        ttk.Button(buttons, text="Refresh evaluation",
                   command=self.refresh_evaluation).pack(side="left")
        ttk.Button(buttons, text="Open One-Class SVM final-test matrix",
                   command=lambda: self.open_result("confusion_matrix_one_class_svm.png")
                   ).pack(side="left", padx=7)
        ttk.Button(buttons, text="Open Isolation Forest final-test matrix",
                   command=lambda: self.open_result("confusion_matrix_isolation_forest.png")
                   ).pack(side="left", padx=7)

        ttk.Label(self.eval_tab, text="Validation results (used for threshold tuning and model selection)",
                  font=("Helvetica", 10, "bold")).pack(anchor="w", pady=(3, 4))
        validation_columns = (
            "Model", "G-mean", "Balanced accuracy", "Recall",
            "Specificity", "MCC", "False positive rate", "False negative rate"
        )
        self.validation_tree = ttk.Treeview(
            self.eval_tab, columns=validation_columns, show="headings", height=3
        )
        validation_widths = [135, 80, 125, 75, 85, 75, 120, 125]
        for col, width in zip(validation_columns, validation_widths):
            self.validation_tree.heading(col, text=col)
            self.validation_tree.column(col, width=width, anchor="center")
        self.validation_tree.pack(fill="x", pady=(0, 10))

        ttk.Label(self.eval_tab, text="Final-test results (held back; not used for model selection)",
                  font=("Helvetica", 10, "bold")).pack(anchor="w", pady=(0, 4))
        final_columns = (
            "Model", "TP", "TN", "FP", "FN", "Balanced accuracy",
            "Recall", "Specificity", "G-mean", "False positive rate", "False negative rate", "MCC"
        )
        self.metrics_tree = ttk.Treeview(
            self.eval_tab, columns=final_columns, show="headings", height=3
        )
        final_widths = [135, 55, 55, 55, 55, 120, 75, 85, 80, 115, 125, 65]
        for col, width in zip(final_columns, final_widths):
            self.metrics_tree.heading(col, text=col)
            self.metrics_tree.column(col, width=width, anchor="center")
        self.metrics_tree.pack(fill="x")

        self.eval_note = tk.Label(
            self.eval_tab, text="", bg="#F3F6FA", fg="#526274",
            justify="left", anchor="w", wraplength=900, font=("Helvetica", 9),
        )
        self.eval_note.pack(fill="x", pady=9)
        ttk.Label(
            self.eval_tab,
            text="Confusion matrices open in macOS Preview (or your default image viewer).",
        ).pack(anchor="w")

    @staticmethod
    def _populate_metrics_tree(tree, metrics, columns):
        for item in tree.get_children():
            tree.delete(item)
        if metrics is None or "Model" not in metrics.columns:
            return
        for _, row in metrics.iterrows():
            values = []
            for col in columns:
                value = row.get(col)
                if col == "Model":
                    values.append(str(value))
                elif pd.isna(value):
                    values.append("N/A")
                elif col in {"TP", "TN", "FP", "FN", "True positives", "True negatives", "False positives", "False negatives"}:
                    values.append(str(int(float(value))))
                elif col == "Target met":
                    values.append(str(value))
                elif col in {"Threshold", "MCC"}:
                    values.append(f"{float(value):.4f}")
                else:
                    values.append(f"{float(value):.1%}")
            tree.insert("", "end", values=values)

    def refresh_evaluation(self):
        if not hasattr(self, "metrics_tree"):
            return

        validation_path = RESULTS / "validation_metrics.csv"
        final_path = RESULTS / "final_test_metrics.csv"
        validation = None
        final = None
        try:
            if validation_path.exists():
                validation = pd.read_csv(validation_path)
            if final_path.exists():
                final = pd.read_csv(final_path)
        except Exception as exc:
            self.eval_note.configure(text=f"Could not read evaluation files: {exc}")
            return

        # Populate the validation table with the selected validation metrics.
        if validation is not None and "Model" in validation.columns:
            self._populate_metrics_tree(
                self.validation_tree, validation,
                ("Model", "G-mean", "Balanced accuracy", "Recall",
                 "Specificity", "MCC", "False positive rate", "False negative rate"),
            )

        self._populate_metrics_tree(
            self.metrics_tree, final,
            ("Model", "True positives", "True negatives", "False positives",
             "False negatives", "Balanced accuracy", "Recall", "Specificity",
             "G-mean", "False positive rate", "False negative rate", "MCC"),
        )

        info = selection_info() or {}
        chosen = info.get("chosen_model")
        if chosen:
            selected_mcc = info.get("selected_validation_mcc")
            selected_balanced = info.get("selected_validation_balanced_accuracy")
            selected_recall = info.get("selected_validation_recall")
            selected_specificity = info.get("selected_validation_specificity")
            selected_fpr = info.get("selected_validation_fpr")
            selected_fnr = info.get("selected_validation_fnr")
            selection_text = (
                f"Default application model: {chosen}. Selected using validation MCC "
                "(which considers TP, TN, FP and FN together). "
                "Final-test data was not used for model or threshold selection."
            )
            if selected_mcc is not None:
                selection_text += f" Validation MCC: {float(selected_mcc):.3f}."
            if selected_balanced is not None:
                selection_text += f" Balanced accuracy: {float(selected_balanced):.1%}."
            if selected_recall is not None and selected_specificity is not None:
                selection_text += (
                    f" Scam recall: {float(selected_recall):.1%}; "
                    f"genuine specificity: {float(selected_specificity):.1%}."
                )
            if selected_fpr is not None and selected_fnr is not None:
                selection_text += (
                    f" FPR: {float(selected_fpr):.1%}; FNR: {float(selected_fnr):.1%}."
                )
            if (selected_fpr is not None and selected_fnr is not None
                    and (float(selected_fpr) > 0.10 or float(selected_fnr) > 0.10)):
                selection_text += (
                    " Some errors remain; use this as a research prototype and manually "
                    "review suspicious messages rather than automatically blocking them."
                )
            self.selection_note.configure(text=selection_text)
        else:
            self.selection_note.configure(text="No validation-selected model found. Run train_evaluate.py first.")

        note = (
            "Each model's threshold is selected on mixed validation data by maximising "
            "G-mean (the geometric mean of scam recall and genuine specificity). "
            "A small pre-defined parameter grid is also compared using validation MCC. "
            "Final testing uses separate held-back scam and verified genuine messages. "
            "G-mean balances scam recall and genuine specificity. "
            "FPR = genuine messages incorrectly flagged; FNR = actual scams missed. "
            "Messages with no known training vocabulary require manual review."
        )
        if validation is None or final is None:
            note += "\nRun train_evaluate.py to generate both validation and final-test results."
        self.eval_note.configure(text=note)

    def open_result(self, filename):
        path = RESULTS / filename
        if not path.is_file():
            messagebox.showinfo(
                "File not found",
                f"{filename} is not available. Run train_evaluate.py with a separate genuine test CSV first.",
            )
            return
        try:
            system = platform.system()
            if system == "Darwin":
                subprocess.Popen(["open", str(path)])
            elif system == "Windows":
                os.startfile(str(path))
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            messagebox.showerror("Could not open file", str(exc))


if __name__ == "__main__":
    SMSScannerDesktop().mainloop()
