# SMS Security Scanner — Balanced Performance Version

This project compares **One-Class SVM** and **Isolation Forest** for SMS scam novelty detection.

The research design remains **scam-only training**:
- 70% of the combined dataset is used for training, containing scam SMS only.
- 15% is used for validation, containing held-back scam and verified genuine SMS.
- 15% is used for final testing, containing different held-back scam and verified genuine SMS.

The project owner has confirmed that `data/genuine_sms.csv` contains verified genuine messages. Genuine messages are not used to fit either model or the text-vectorisation pipeline.

## 1. What changed in this version?

The earlier 90% scam-recall target encouraged the models to flag many messages as scam-like. That increased scam recall but also caused an unacceptable number of genuine messages to be flagged.

This version no longer forces a 90% recall target. Instead, it aims for a better balance between both classes.

### Threshold selection

For each model, the decision threshold is selected using the mixed validation data by maximising **G-mean**:

`G-mean = sqrt(Scam recall × Genuine-message specificity)`

G-mean is useful when both classes matter. It penalises a model if it detects scams well but performs poorly on genuine messages, or vice versa.

If two thresholds have the same G-mean, the code prefers higher MCC and balanced accuracy, then lower false-positive and false-negative rates.

### Hyperparameter selection

Exactly 30 pre-defined parameter configurations are tested for each algorithm. Every candidate model is fitted using the same scam-only training partition. Both algorithms use the same mixed validation partition, the same G-mean threshold-selection rule, and the same validation **Matthews correlation coefficient (MCC)** model-selection rule, with balanced accuracy, F1 and lower error rates as tie-breakers.

MCC considers all four confusion-matrix outcomes: TP, TN, FP and FN.

The default desktop-app model is then selected by comparing the two algorithms using validation MCC. **The final-test set is not used for parameter tuning, threshold selection or model selection.**

## 2. Text processing improvements

The vectorisation pipeline now combines:

- **Word-level TF-IDF:** captures words and short phrases, such as `verify account` or `delivery pending`.
- **Character-level TF-IDF:** captures spelling patterns, word fragments and some altered spellings.
- **TruncatedSVD:** reduces the combined sparse feature space.
- **L2 normalisation:** scales the reduced text vectors before model fitting.

Both word and character TF-IDF vectorisers, SVD and the normaliser are fitted using scam training messages only. Validation and test messages are transformed using the already-fitted pipeline.

This richer feature representation improved separation in exploratory development runs. The delivered code uses a fresh default split seed for the next final evaluation; performance on future SMS is not guaranteed.

## 3. Data split

The target proportions are based on the combined number of eligible scam and genuine messages:

| Split | Target share | Content |
|---|---:|---|
| Training | 70% | Scam messages only |
| Validation | 15% | Held-back scam + genuine messages |
| Final testing | 15% | Different held-back scam + genuine messages |

The code groups normalised message templates before splitting to reduce leakage. Actual percentages may differ slightly because complete template groups are kept together. Check `results/split_counts.csv` for the exact counts.

All genuine messages are excluded from training. If there are not enough eligible scam messages to fill the requested training share, the script stops rather than silently changing the research design.

## 4. Important limitation

One-Class SVM and Isolation Forest learn the distribution of scam messages; they do not learn a complete genuine-message class during training. Genuine validation messages help select thresholds and model settings, but they are not used to fit the models.

There is no setting that can guarantee high TP and TN and low FP and FN simultaneously. If scam and genuine messages have overlapping language patterns, some errors are unavoidable. The purpose of G-mean threshold selection and validation-based model tuning is to find the best measured trade-off without using final-test data. For dissertation reporting, freeze the code and settings before running the final evaluation. Do not repeatedly change the model after viewing final-test results.

A message outside the learned scam pattern is **not automatically proven safe**. Messages with no overlap with the scam-training vocabulary are marked **INSUFFICIENT EVIDENCE — MANUAL REVIEW**.

## 5. Measures against memorisation and overfitting

1. Exact duplicate messages are removed before splitting.
2. Variable-field message templates are normalised and grouped before splitting.
3. The code checks that a normalised scam template does not cross scam training, validation and test partitions.
4. Genuine templates are kept separate between validation and final testing.
5. Word and character TF-IDF, SVD and Normalizer are fitted on scam training messages only.
6. A small pre-defined model-parameter grid is compared using validation data only.
7. Thresholds and the default model are selected using validation data only.
8. Final-test data is held back for final reporting and is not used to adjust the model.

These safeguards reduce common leakage and overfitting risks, but they cannot guarantee performance on every future SMS.

## 6. Dataset requirements

### Scam CSV: `data/scams.csv`

Required columns:
- `text`: SMS message content.
- `scam_type`: category label used only to select eligible scam records and balance the split.

The current script includes the categories `banking`, `others`, `government`, `delivery`, `telecom`, `wrong number` and `hey mum/dad`. Generic spam and blank labels are excluded. Only `text` is passed to the models.

### Genuine CSV: `data/genuine_sms.csv`

Required column:
- `text`: verified genuine SMS content.

Genuine messages are used only for validation and final testing, never for model fitting.

## 7. Install on macOS

Open the extracted project folder in VS Code and open its Terminal:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Select `.venv/bin/python` in VS Code using **Command + Shift + P → Python: Select Interpreter**. The default split seed is `2027`.

Check Tkinter:

```bash
python -m tkinter
```

A small test window should appear. Close it.

## 8. Run the project

Run from the project root:

```bash
python train_evaluate.py \
  --scams data/scams.csv \
  --genuine data/genuine_sms.csv \
  --genuine-source verified
```

Then launch the native Mac desktop application:

```bash
python desktop_app.py
```

The app supports single-message scanning and batch scanning from a CSV containing a `text` column. It does not automatically read the Mac or iPhone Messages inbox.

## 9. Main output files

| File | Purpose |
|---|---|
| `model_one_class_svm.joblib` | Selected One-Class SVM and fitted text pipeline |
| `model_isolation_forest.joblib` | Selected Isolation Forest and fitted text pipeline |
| `model_selection.json` | Model selected using validation only |
| `validation_metrics.csv` | Validation TP/TN/FP/FN, rates, threshold and settings |
| `final_test_metrics.csv` | Final TP/TN/FP/FN and performance metrics |
| `split_counts.csv` | Actual 70/15/15 split counts and percentages |
| `confusion_matrix_one_class_svm.png` | One-Class SVM final-test confusion matrix |
| `confusion_matrix_isolation_forest.png` | Isolation Forest final-test confusion matrix |

Exactly **two confusion-matrix images** are produced: one per model, both from final testing only. There are no validation confusion-matrix images.

## 10. Academic reporting

Earlier runs and the seed-2027 test results are development diagnostics. The current expanded search is assessed on validation data only. A new independent set of scam and verified genuine messages is required for an unbiased final dissertation evaluation. Do not describe the 90% scam-recall target from the previous version as a guarantee or as a result of this version. Discuss both false negatives and false positives, and explain that scam-only novelty detection has limitations because genuine messages are not used to train the models.


## 11. Latest optimisation

- TruncatedSVD now retains 240 components by default (previously 120), preserving more dimensions from the combined word-level and character-level TF-IDF representation.
- Isolation Forest compares 30 pre-defined parameter combinations covering tree count, sample size and feature fraction.
- Every candidate is fitted on scam training messages only.
- Mixed validation messages are used for threshold and model selection.
- Thresholds are selected using validation G-mean; model configurations are ranked using validation MCC, then balanced accuracy, F1 and lower error rates.
- Final-test data is not used to choose parameters, thresholds or the default application model.

These changes aim to improve the balance between scam detection and genuine-message recognition. They do not guarantee particular TP, TN, FP or FN counts.


## 12. Fair comparison of both algorithms

Both One-Class SVM and Isolation Forest receive the same 30-candidate tuning budget.

### One-Class SVM candidates

- `nu`: 0.005, 0.01, 0.05
- `gamma`: 0.001, `auto`, `scale`
- Total: 3 × 3 = 9 configurations

### Isolation Forest candidates

Thirty pre-defined combinations of:
- `n_estimators` (tree count)
- `max_samples` (sample fraction)
- `max_features` (feature fraction)

### Shared experimental rules

Both algorithms:
1. Use the exact same 70/15/15 grouped data split.
2. Fit only on the 70% scam-only training partition.
3. Use the same word + character TF-IDF and 240-component TruncatedSVD representation.
4. Select each candidate's decision threshold on mixed validation data by maximising G-mean.
5. Select the best candidate using validation MCC, with the same tie-breakers.
6. Are evaluated once on the same held-back final-test partition after their settings and thresholds have been selected.

The algorithms have different hyperparameters, so their parameter values are not identical. Fairness here means equal candidate counts, identical data, identical feature processing, identical threshold objective and identical model-selection criteria.

The default split seed remains 2027 for reproducibility. This test partition has already been examined during development; it is not a fresh independent test set for final dissertation claims. Collect new independent scam and verified genuine messages before claiming unbiased final-test performance.


## 13. Expanded fair search (30 candidates per algorithm)

The latest version tests 30 candidate configurations for each algorithm.

**One-Class SVM:** five `nu` values (0.05, 0.1, 0.3, 0.5, 0.7) crossed with six `gamma` values (0.0001, 0.001, 0.005, 0.01, 0.05, `scale`).

**Isolation Forest:** five tree counts (300, 400, 600, 800, 1000), three sample fractions (0.5, 0.75, 1.0), and two feature fractions (0.5, 1.0).

Both use the same scam-only training partition, mixed validation partition, 240-component word + character TF-IDF representation, G-mean threshold selection, and MCC-based model selection.

The expanded search was assessed on the existing validation partition only. Do not interpret these validation results as final-test results. The seed-2027 final-test set has already been viewed during development, so it should not be used to claim a fresh unbiased final evaluation. For dissertation-grade final results, collect a new independent set of scam and verified genuine messages that was not used in any previous tuning or evaluation.
